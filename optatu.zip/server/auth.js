module.exports = {

    'facebookAuth' : {
        'clientID'      : '373698066413307', // your App ID
        'clientSecret'  : 'ce80b8fcd30fa02ddb5980bd7d2457e0', // your App Secret
        'callbackURL'   : 'http://springtv.it/auth/facebook/callback'
    }
//    ,
//
//    'twitterAuth' : {
//        'consumerKey'       : 'your-consumer-key-here',
//        'consumerSecret'    : 'your-client-secret-here',
//        'callbackURL'       : 'http://localhost:8080/auth/twitter/callback'
//    },
//
//    'googleAuth' : {
//        'clientID'      : '518076352499-bq5143pu7mfgfg2defhk66biv0p68blfelm.apps.googleusercontent.com',
//        'clientSecret'  : 'dYp3-v8HvfgfdgfdgH7opy9EybrDZkYz',
//        'callbackURL'   : 'http://localhost:8080/auth/google/callback'
//    }

};